npx tailwindcss -i ./tailwind.css -o ./main.css --watch
